"""Check MongoDB connectivity using the project's configured environment."""
import os
import sys
from dotenv import load_dotenv

load_dotenv()

from app.database import MongoDBManager  # noqa: E402


def main() -> int:
    uri = MongoDBManager.get_uri()
    if "@" in uri:
        scheme = uri.split("://", 1)[0]
        uri = f"{scheme}://****:****@{uri.split('@', 1)[1]}"
    print(f"MongoDB target: {uri}")
    print(f"Database: {MongoDBManager.get_db_name()}")
    result = MongoDBManager.ping()
    if result["status"] == "ok":
        print("SUCCESS: MongoDB ping succeeded.")
        return 0
    print(f"FAILED: MongoDB connection was not verified: {result.get('error', 'unknown error')}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
