"""Central MongoDB configuration and connectivity helpers.

Supported environment variables:
  MONGO_URI / MONGODB_URI: MongoDB connection URI (default: local MongoDB)
  MONGO_DB / DATABASE_NAME: database name (default: attendance_db)
  MONGO_TIMEOUT_MS / SERVER_SELECTION_TIMEOUT_MS: connection selection timeout

The MongoClient is lazy: creating this module does not prove a server is reachable.
Call ping() or run `python check_mongodb.py` to verify connectivity.
"""
from __future__ import annotations

import logging
import os
from typing import Optional, Any
from datetime import timezone

from pymongo import MongoClient
from pymongo.errors import PyMongoError

log = logging.getLogger("attendance.database")


def _env_int(primary: str, secondary: str, default: int) -> int:
    raw = os.getenv(primary, os.getenv(secondary, str(default)))
    try:
        value = int(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{primary} must be an integer") from exc
    if value <= 0:
        raise ValueError(f"{primary} must be greater than zero")
    return value


class MongoDBManager:
    """Small singleton manager that retains the project's existing sync PyMongo API."""

    _client: Optional[MongoClient] = None
    _db: Optional[Any] = None

    @classmethod
    def get_uri(cls) -> str:
        return os.getenv("MONGO_URI", os.getenv("MONGODB_URI", "mongodb://localhost:27017"))

    @classmethod
    def get_db_name(cls) -> str:
        return os.getenv("MONGO_DB", os.getenv("DATABASE_NAME", "attendance_db"))

    @classmethod
    def get_timeout_ms(cls) -> int:
        return _env_int("MONGO_TIMEOUT_MS", "SERVER_SELECTION_TIMEOUT_MS", 5000)

    @classmethod
    def connect(cls) -> Any:
        if cls._client is None:
            uri = cls.get_uri().strip()
            if not uri:
                raise ValueError("MONGO_URI is empty; configure it in your environment or .env file")
            timeout = cls.get_timeout_ms()
            cls._client = MongoClient(
                uri,
                tz_aware=True,
                tzinfo=timezone.utc,
                serverSelectionTimeoutMS=timeout,
                connectTimeoutMS=timeout,
                socketTimeoutMS=timeout,
            )
            cls._db = cls._client[cls.get_db_name()]
        return cls._db  # type: ignore[return-value]

    @classmethod
    def get_db(cls) -> Any:
        return cls._db if cls._db is not None else cls.connect()

    @classmethod
    def get_client(cls) -> MongoClient:
        if cls._client is None:
            cls.connect()
        return cls._client  # type: ignore[return-value]

    @classmethod
    def ping(cls) -> dict:
        try:
            cls.get_client().admin.command("ping")
            return {"status": "ok", "message": "MongoDB connection responsive"}
        except Exception as exc:
            log.warning("MongoDB ping failed: %s", exc)
            return {"status": "error", "error": str(exc)}

    @classmethod
    def close(cls) -> None:
        if cls._client is not None:
            cls._client.close()
        cls._client = None
        cls._db = None


def get_database() -> Any:
    return MongoDBManager.get_db()


# Preserve the names and behavior previously imported directly by app.main.
client = MongoDBManager.get_client()
db = MongoDBManager.get_db()
