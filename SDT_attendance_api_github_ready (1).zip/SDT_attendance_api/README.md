# SDT Attendance API

Employee attendance and analytics REST API built with FastAPI, PyMongo, and MongoDB. Existing API routes and business rules remain in `app/main.py`; MongoDB configuration and connectivity checks are centralized in `app/database.py`.

## Requirements

- Python 3.11 or newer
- MongoDB 6.0+ (local Docker container or MongoDB Atlas)

## Windows quick start (local MongoDB with Docker)

1. Install Docker Desktop and start it.
2. In PowerShell, from this project folder:

```powershell
Copy-Item .env.example .env
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
docker compose up -d mongodb
.\.venv\Scripts\python.exe check_mongodb.py
.\.venv\Scripts\python.exe -m unittest tests.test_rules tests.test_handlers_sim -v
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/docs` for API documentation. Check `http://127.0.0.1:8000/health` for database health.

## MongoDB Atlas

1. Create a cluster at https://cloud.mongodb.com.
2. Create a database user and allow your current public IP under Network Access.
3. Copy the connection URI from **Connect → Drivers**.
4. Edit the local `.env` file (never commit it):

```dotenv
MONGO_URI=mongodb+srv://USERNAME:URL_ENCODED_PASSWORD@YOUR_CLUSTER_HOST/?retryWrites=true&w=majority
MONGO_DB=attendance_db
MONGO_TIMEOUT_MS=10000
```

Use your real username, password, and cluster hostname locally. URL-encode special characters in the password. Do not paste credentials into public issues or commit them to GitHub. `app/database.py` also accepts `MONGODB_URI`, `DATABASE_NAME`, and `SERVER_SELECTION_TIMEOUT_MS` as compatibility aliases.

Verify the real connection:

```powershell
.\.venv\Scripts\python.exe check_mongodb.py
```

A successful run prints `SUCCESS: MongoDB ping succeeded.` A failed run exits with a non-zero code. The mere presence of a URI does not prove connectivity.

## Tests

Database-independent rules and handler simulation tests:

```powershell
.\.venv\Scripts\python.exe -m unittest tests.test_rules tests.test_handlers_sim -v
```

The integration suite in `tests/test_api.py` uses a real MongoDB server and a disposable database named `attendance_test`; it drops that database before and after tests. **Only run it against a throw-away development cluster with no valuable data.**

```powershell
.\.venv\Scripts\python.exe -m pytest tests/test_api.py -v
```

The integration suite and scale test have not been verified against a live MongoDB server in this packaged environment. GitHub Actions runs the database-independent tests only and does not claim that a live database was reached.

## Seed sample data (optional)

After configuring and verifying MongoDB, run:

```powershell
.\.venv\Scripts\python.exe sample_seed.py
```

Review `sample_seed.py` before running it against any database that contains data.

## GitHub upload

Create an empty repository on GitHub, then run in this folder:

```powershell
git init
git add .
git status
git commit -m "Prepare attendance API with MongoDB configuration and tests"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/SDT_attendance_api.git
git push -u origin main
```

Check `git status` before committing and ensure `.env` is not staged. Never commit database credentials.
