"""Integration tests. REQUIRE a running MongoDB (MONGO_URI, default mongodb://localhost:27017) and
`pip install -r requirements.txt pytest httpx`.  Uses the throw-away database `attendance_test`.

    pytest tests/test_api.py -v
"""
import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta

os.environ["MONGO_DB"] = "attendance_test"

import pytest
from fastapi.testclient import TestClient

from app import main

IST = timezone(timedelta(hours=5, minutes=30))


def ms(y, mo, d, h=0, mi=0, s=0, tz=IST):
    return int(datetime(y, mo, d, h, mi, s, tzinfo=tz).timestamp() * 1000)


@pytest.fixture(scope="module")
def c():
    main.client.drop_database("attendance_test")
    with TestClient(main.app) as cl:  # runs lifespan -> indexes
        yield cl
    main.client.drop_database("attendance_test")


def emp(c, code, dept="Eng", ss="09:30", se="18:30", joined="2026-01-05"):
    r = c.post("/employees", json={"emp_code": code, "name": code, "email": f"{code}@x.io", "department": dept,
                                   "shift_start": ss, "shift_end": se, "joined_on": joined})
    assert r.status_code == 201, r.text
    return r.json()


def test_health_and_employee_crud(c):
    assert c.get("/health").json() == {"status": "ok"}
    e = emp(c, "EMP0001")
    assert isinstance(e["created_at"], int) and "_id" not in e
    assert c.post("/employees", json={**e, "created_at": 1}).status_code == 409
    assert c.post("/employees", json={"emp_code": "X1", "name": "a", "email": "a@b.co", "department": "d",
                                      "joined_on": "2026-01-01"}).status_code == 422
    assert c.post("/employees", json={"emp_code": "EMP0099", "name": "a", "email": "a@b.co", "department": "d",
                                      "shift_start": "09:00", "shift_end": "09:00",
                                      "joined_on": "2026-01-01"}).status_code == 422
    for i in range(2, 6):
        emp(c, f"EMP000{i}", dept="Ops")
    r = c.get("/employees", params={"department": "Ops", "page": 1, "page_size": 3}).json()
    assert r["total"] == 4 and [i["emp_code"] for i in r["items"]] == ["EMP0002", "EMP0003", "EMP0004"]
    assert c.get("/employees", params={"page": 0}).status_code == 422
    assert c.get("/employees", params={"page_size": 101}).status_code == 422


def test_concurrent_creates_one_winner(c):
    body = {"emp_code": "EMP0777", "name": "r", "email": "r@x.io", "department": "Eng", "joined_on": "2026-01-01"}
    with ThreadPoolExecutor(10) as ex:
        codes = sorted(ex.map(lambda _: c.post("/employees", json=body).status_code, range(10)))
    assert codes == [201] + [409] * 9


def test_punch_in_out_rules(c):
    r = c.post("/attendance/punch-in", json={"emp_code": "EMP0001", "punched_at": ms(2026, 7, 6, 9, 40, 1)})
    assert r.status_code == 201 and r.json()["late_minutes"] == 10 and r.json()["date"] == "2026-07-06"
    assert c.post("/attendance/punch-in", json={"emp_code": "EMP0001", "punched_at": ms(2026, 7, 6, 11)}).status_code == 409
    assert c.post("/attendance/punch-in", json={"emp_code": "NOPE", "punched_at": ms(2026, 7, 6, 11)}).status_code == 404
    for bad in (1783312500, 1.5, "x", True, 5_000_000_000_000):
        assert c.post("/attendance/punch-in", json={"emp_code": "EMP0002", "punched_at": bad}).status_code == 422
    assert c.post("/attendance/punch-in", json={"emp_code": "EMP0002", "status": "ABSENT"}).status_code == 422
    o = c.post("/attendance/punch-out", json={"emp_code": "EMP0001", "punched_at": ms(2026, 7, 6, 19, 10)})
    assert o.status_code == 200
    j = o.json()
    assert j["overtime_minutes"] == 40 and j["half_day"] is False and j["work_hours"] == 9.5  # 09:40:01 -> 19:10
    assert c.post("/attendance/punch-out", json={"emp_code": "EMP0001", "punched_at": ms(2026, 7, 6, 19, 20)}).status_code == 409
    assert c.post("/attendance/punch-out", json={"emp_code": "EMP0003", "punched_at": ms(2026, 7, 6, 19)}).status_code == 404


def test_overnight_punch_out_across_midnight(c):
    emp(c, "EMP0010", dept="Night", ss="22:00", se="06:00")
    r = c.post("/attendance/punch-in", json={"emp_code": "EMP0010", "punched_at": ms(2026, 7, 6, 21, 55)})
    assert r.json()["date"] == "2026-07-06"
    o = c.post("/attendance/punch-out", json={"emp_code": "EMP0010", "punched_at": ms(2026, 7, 7, 6, 40)})
    assert o.status_code == 200 and o.json()["overtime_minutes"] == 40 and o.json()["work_hours"] == 8.75
    r2 = c.post("/attendance/punch-in", json={"emp_code": "EMP0010", "punched_at": ms(2026, 7, 8, 2, 0)})
    assert r2.json()["date"] == "2026-07-07"


def test_concurrent_punch_in_and_out(c):
    emp(c, "EMP0020")
    with ThreadPoolExecutor(10) as ex:
        codes = sorted(ex.map(lambda _: c.post("/attendance/punch-in", json={
            "emp_code": "EMP0020", "punched_at": ms(2026, 7, 6, 9, 30)}).status_code, range(10)))
    assert codes == [201] + [409] * 9
    with ThreadPoolExecutor(10) as ex:
        codes = sorted(ex.map(lambda _: c.post("/attendance/punch-out", json={
            "emp_code": "EMP0020", "punched_at": ms(2026, 7, 6, 18, 30)}).status_code, range(10)))
    assert codes == [200] + [409] * 9


def test_regularize(c):
    url = "/attendance/EMP0001/2026-07-06"
    base = {"reason": "biometric glitch", "regularized_by": "hr"}
    assert c.patch(url, json=base).status_code == 422  # changes nothing
    r = c.patch(url, json={**base, "punch_in": ms(2026, 7, 6, 9, 28)})
    assert r.status_code == 200
    j = r.json()
    assert j["late_minutes"] == 0 and len(j["history"]) == 1
    ch = j["history"][0]["changes"]
    assert ch["late_minutes"] == {"from": 10, "to": 0} and isinstance(ch["punch_in"]["from"], int)
    assert c.patch(url, json={**base, "status": "LEAVE", "punch_in": ms(2026, 7, 6, 9)}).status_code == 422
    assert c.patch(url, json={**base, "punch_in": ms(2026, 7, 7, 9)}).status_code == 422  # other date
    assert c.patch("/attendance/EMP0001/2026-07-09", json=base).status_code == 404
    assert c.patch("/attendance/NOPE/2026-07-06", json=base).status_code == 404
    r = c.patch(url, json={**base, "status": "LEAVE"})
    assert r.status_code == 200 and r.json()["punch_in"] is None and len(r.json()["history"]) == 2
    assert c.patch(url, json={**base, "status": "PRESENT"}).status_code == 422  # needs punch_in


def test_list_attendance(c):
    r = c.get("/attendance", params={"emp_code": "EMP0010"}).json()
    assert r["total"] == 2 and [i["date"] for i in r["items"]] == ["2026-07-07", "2026-07-06"]
    assert c.get("/attendance", params={"date_from": "2026-07-09", "date_to": "2026-07-01"}).status_code == 422
    assert c.get("/attendance", params={"date_from": "2026-02-30"}).status_code == 422
    assert c.get("/attendance", params={"status": "BOGUS"}).status_code == 422
    assert all("id" not in i for i in c.get("/attendance").json()["items"])


def seed_analytics():
    """Hand-built awkward data for the analytics tests (inserted directly, like the grader does)."""
    d = main.db
    d.employees.delete_many({"department": "A"})
    d.attendance_logs.delete_many({"emp_code": {"$regex": "^EMP9"}})
    mk = lambda code, joined: {"emp_code": code, "name": code, "email": "e@x.io", "department": "A",
                               "shift_start": "09:30", "shift_end": "18:30", "joined_on": joined,
                               "created_at": datetime(2026, 1, 1, tzinfo=timezone.utc)}
    d.employees.insert_many([mk("EMP9001", "2026-01-01"), mk("EMP9002", "2026-01-01"), mk("EMP9003", "2026-01-01"),
                             mk("EMP9004", "2026-01-01"), mk("EMP9005", "2026-07-15"), mk("EMP9006", "2026-08-01")])

    def log(code, day, status="PRESENT", late=0, ot=0, wh=8.0, half=False):
        pres = status in ("PRESENT", "WFH", "ON_DUTY")
        d.attendance_logs.insert_one({"emp_code": code, "date": day, "status": status,
                                      "punch_in": datetime(2026, 7, 1, 4, tzinfo=timezone.utc) if pres else None,
                                      "punch_out": datetime(2026, 7, 1, 12, tzinfo=timezone.utc) if pres else None,
                                      "work_hours": wh if pres else None, "late_minutes": late,
                                      "overtime_minutes": ot, "half_day": half})
    log("EMP9001", "2026-07-06", late=30, ot=40)
    log("EMP9001", "2026-07-07", half=True, wh=3.5)
    log("EMP9001", "2026-07-08", "LEAVE")
    log("EMP9001", "2026-07-11", late=20)  # Saturday: counts for late, not present_days
    log("EMP9002", "2026-07-06", late=40)
    log("EMP9003", "2026-07-06", late=30)
    log("EMP9003", "2026-07-07", late=10)
    log("EMP9004", "2026-07-06", late=60)
    log("EMP9004", "2026-07-07", "ON_DUTY", wh=6.0)
    log("EMP9004", "2026-07-08", "ABSENT")
    log("EMP9005", "2026-07-15", wh=9.0)
    log("EMP9999", "2026-07-06", late=500)  # unknown employee: ignored by the leaderboard


def test_employee_monthly(c):
    seed_analytics()
    j = c.get("/analytics/employees/EMP9001/monthly", params={"month": "2026-07"}).json()
    assert j == {"emp_code": "EMP9001", "month": "2026-07", "working_days": 23, "present_days": 1.5,
                 "leave_days": 1, "late_count": 2, "total_late_minutes": 50, "total_overtime_minutes": 40,
                 "attendance_pct": 6.52}
    j = c.get("/analytics/employees/EMP9005/monthly", params={"month": "2026-07"}).json()
    assert j["working_days"] == 13 and j["present_days"] == 1.0 and j["attendance_pct"] == 7.69
    j = c.get("/analytics/employees/EMP9006/monthly", params={"month": "2026-07"}).json()
    assert j["working_days"] == 0 and j["attendance_pct"] is None
    assert c.get("/analytics/employees/NOPE/monthly", params={"month": "2026-07"}).status_code == 404
    assert c.get("/analytics/employees/EMP9001/monthly", params={"month": "2026-13"}).status_code == 422


def test_department_summary(c):
    j = c.get("/analytics/departments/summary", params={"month": "2026-07", "department": "A"}).json()
    assert j["items"] == [{"department": "A", "headcount": 5, "present_days": 7.5, "avg_work_hours": 7.39,
                           "late_count": 6, "total_late_minutes": 190, "leave_count": 1, "on_duty_count": 1}]
    names = [i["department"] for i in c.get("/analytics/departments/summary", params={"month": "2026-07"}).json()["items"]]
    assert names == sorted(names)
    # January: four employees joined, none has logs -> still counted, average is null
    j = c.get("/analytics/departments/summary", params={"month": "2026-01", "department": "A"}).json()
    assert j["items"] == [{"department": "A", "headcount": 4, "present_days": 0.0, "avg_work_hours": None,
                           "late_count": 0, "total_late_minutes": 0, "leave_count": 0, "on_duty_count": 0}]


def test_leaderboard_ties(c):
    p = {"month": "2026-07", "department": "A"}
    two = c.get("/analytics/leaderboard/late", params={**p, "limit": 2}).json()["items"]
    assert [(i["rank"], i["emp_code"]) for i in two] == [(1, "EMP9004"), (2, "EMP9001")]
    # EMP9002 and EMP9003 tie on 40 minutes at rank 3 -> both returned (more rows than limit), emp_code order
    three = c.get("/analytics/leaderboard/late", params={**p, "limit": 3}).json()["items"]
    assert [(i["rank"], i["emp_code"], i["total_late_minutes"]) for i in three] == [
        (1, "EMP9004", 60), (2, "EMP9001", 50), (3, "EMP9002", 40), (3, "EMP9003", 40)]
    assert three[0]["late_count"] == 1 and three[0]["name"] == "EMP9004" and three[0]["department"] == "A"
    full = c.get("/analytics/leaderboard/late", params={**p, "limit": 50}).json()["items"]
    assert [i["rank"] for i in full] == [1, 2, 3, 3]  # EMP9005 (0 late) and unknown EMP9999 are absent
    assert c.get("/analytics/leaderboard/late", params={**p, "limit": 0}).status_code == 422
    assert c.get("/analytics/leaderboard/late", params={**p, "limit": 51}).status_code == 422


def test_trend(c):
    rows = c.get("/analytics/departments/A/trend", params={"from": "2026-07-04", "to": "2026-07-10"}).json()["items"]
    assert [r["date"] for r in rows] == [f"2026-07-{d:02d}" for d in range(4, 11)]
    assert [r["is_working_day"] for r in rows] == [False, False, True, True, True, True, True]
    assert rows[0]["attendance_rate"] is None and rows[0]["moving_avg_7d"] is None  # weekend, no window yet
    mon, tue, wed, thu = rows[2], rows[3], rows[4], rows[5]
    assert (mon["headcount"], mon["present_count"], mon["late_count"]) == (4, 4, 4)
    assert mon["attendance_rate"] == 1.0 and mon["moving_avg_7d"] == 1.0
    assert tue["present_count"] == 2.5 and tue["attendance_rate"] == 0.625 and tue["moving_avg_7d"] == 0.8125
    assert wed["attendance_rate"] == 0.0 and wed["moving_avg_7d"] == 0.5417  # LEAVE/ABSENT: rate 0.0, not null
    assert thu["present_count"] == 0 and thu["attendance_rate"] == 0.0  # working day with no records
    assert c.get("/analytics/departments/Nope/trend", params={"from": "2026-07-01", "to": "2026-07-02"}).status_code == 404
    assert c.get("/analytics/departments/A/trend", params={"from": "2026-07-05", "to": "2026-07-01"}).status_code == 422
    assert c.get("/analytics/departments/A/trend", params={"from": "2026-01-01", "to": "2026-06-01"}).status_code == 422
    assert len(c.get("/analytics/departments/A/trend", params={"from": "2026-07-01", "to": "2026-09-30"}).json()["items"]) == 92


@pytest.mark.parametrize("endpoint,params", [
    ("attendance_list", {}),
    ("attendance_list", {"emp_code": "EMP0001", "date_from": "2026-07-01"}),
    ("employee_monthly", {"emp_code": "EMP9001", "month": "2026-07"}),
    ("department_summary", {"month": "2026-07"}),
    ("late_leaderboard", {"month": "2026-07"}),
    ("department_trend", {"department": "A", "from": "2026-07-01", "to": "2026-07-31"}),
])
def test_explain_uses_index(c, endpoint, params):
    r = c.get(f"/admin/explain/{endpoint}", params=params)
    assert r.status_code == 200, r.text
    text = r.text
    assert "IXSCAN" in text and "COLLSCAN" not in text


def test_explain_missing_params(c):
    assert c.get("/admin/explain/employee_monthly").status_code == 422
    assert c.get("/admin/explain/bogus").status_code == 422


def test_indexes_exist_and_unique(c):
    emp = main.db.employees.index_information()
    att = main.db.attendance_logs.index_information()
    assert emp["uq_emp_code"]["unique"] is True and emp["uq_emp_code"]["key"] == [("emp_code", 1)]
    assert att["uq_emp_date"]["unique"] is True and att["uq_emp_date"]["key"] == [("emp_code", 1), ("date", 1)]
    assert {"date_emp", "status_date_emp", "emp_punchin"} <= set(att)
    main.ensure_indexes()  # idempotent: second call must not raise
    with pytest.raises(main.DuplicateKeyError):  # the database itself, not the handler, rejects duplicates
        main.db.attendance_logs.insert_many([{"emp_code": "EMPDUP1", "date": "2026-07-01", "status": "ABSENT"}] * 2)
