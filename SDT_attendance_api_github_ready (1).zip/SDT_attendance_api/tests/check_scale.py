"""Scale check (NOT a pytest test). Needs a real MongoDB. Loads ~100,000 attendance records into the throw-away
database `attendance_scale`, then prints status, latency and IXSCAN/COLLSCAN for every endpoint, plus explain output.

    python -m tests.check_scale            # exit code 1 if any explain shows COLLSCAN or an endpoint is slow/non-200
"""
import os
import random
import sys
import time
from datetime import datetime, timedelta, timezone

os.environ["MONGO_DB"] = "attendance_scale"
from fastapi.testclient import TestClient  # noqa: E402

from app import main  # noqa: E402

random.seed(7)
main.client.drop_database("attendance_scale")
main.ensure_indexes()
depts = ["Eng", "Ops", "Sales", "HR", "Finance"]
emps = [{"emp_code": f"EMP{i:04d}", "name": f"Name {i}", "email": f"e{i}@x.io", "department": depts[i % 5],
         "shift_start": "09:30", "shift_end": "18:30", "joined_on": "2025-01-01",
         "created_at": datetime(2025, 1, 1, tzinfo=timezone.utc)} for i in range(1, 401)]
main.db.employees.insert_many(emps)
days = [d for d in (datetime(2025, 8, 1) + timedelta(days=n) for n in range(400)) if d.weekday() < 5][:250]
batch, total = [], 0
for e in emps:
    for d in days:
        late = random.choice([0, 0, 0, 12, 35, 70])
        pin = datetime(d.year, d.month, d.day, 4, 0, tzinfo=timezone.utc) + timedelta(minutes=late)
        batch.append({"emp_code": e["emp_code"], "date": d.strftime("%Y-%m-%d"), "status": "PRESENT", "punch_in": pin,
                      "punch_out": pin + timedelta(hours=9), "work_hours": 9.0, "late_minutes": late,
                      "overtime_minutes": 0, "half_day": False, "history": []})
        if len(batch) == 10000:
            main.db.attendance_logs.insert_many(batch)
            total += len(batch)
            batch = []
main.db.attendance_logs.insert_many(batch)
total += len(batch)
print(f"loaded {total} attendance records, {len(emps)} employees")

calls = [
    ("GET", "/attendance", {"page": 1, "page_size": 50}),
    ("GET", "/attendance", {"emp_code": "EMP0007", "date_from": "2025-09-01", "date_to": "2025-09-30"}),
    ("GET", "/attendance", {"status": "PRESENT", "page": 3}),
    ("GET", "/analytics/employees/EMP0007/monthly", {"month": "2025-09"}),
    ("GET", "/analytics/departments/summary", {"month": "2025-09"}),
    ("GET", "/analytics/leaderboard/late", {"month": "2025-09", "limit": 5}),
    ("GET", "/analytics/departments/Eng/trend", {"from": "2025-08-01", "to": "2025-10-31"}),
]
explains = [
    ("attendance_list", {}), ("attendance_list", {"emp_code": "EMP0007"}), ("attendance_list", {"status": "PRESENT"}),
    ("employee_monthly", {"emp_code": "EMP0007", "month": "2025-09"}), ("department_summary", {"month": "2025-09"}),
    ("late_leaderboard", {"month": "2025-09"}),
    ("department_trend", {"department": "Eng", "from": "2025-08-01", "to": "2025-10-31"}),
]
bad = 0
with TestClient(main.app) as c:
    for _, url, params in calls:
        t = time.perf_counter()
        r = c.get(url, params=params)
        ms = (time.perf_counter() - t) * 1000
        ok = r.status_code == 200 and ms < 2000
        bad += not ok
        print(f"{'OK ' if ok else 'BAD'} {r.status_code} {ms:7.0f} ms  {url} {params}")
    for ep, params in explains:
        r = c.get(f"/admin/explain/{ep}", params=params)
        txt = r.text
        ok = r.status_code == 200 and "IXSCAN" in txt and "COLLSCAN" not in txt
        bad += not ok
        print(f"{'OK ' if ok else 'BAD'} explain {ep:20s} {params}  IXSCAN={'IXSCAN' in txt} COLLSCAN={'COLLSCAN' in txt}")
main.client.drop_database("attendance_scale")
sys.exit(1 if bad else 0)
