"""SIMULATION tests: run the real handler functions of app/main.py against an in-memory fake of the two
collections, with fastapi/pydantic/pymongo replaced by tiny stubs. Needs only the standard library.

What this proves: the Python logic of the handlers (order of checks, status codes, history entries, optimistic
concurrency branches, pagination arithmetic, explain command construction, pipeline construction).
What it does NOT prove: anything about MongoDB itself (index use, aggregation semantics, true atomicity),
pydantic/FastAPI validation, or HTTP behaviour.  Those need tests/test_api.py + a real MongoDB.

    python -m unittest tests.test_handlers_sim -v
"""
import copy
import importlib.util
import json
import pathlib
import sys
import threading
import types
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace as NS
from unittest import mock

MAIN = pathlib.Path(__file__).resolve().parent.parent / "app" / "main.py"
IST = timezone(timedelta(hours=5, minutes=30))


def ms(y, mo, d, h=0, mi=0, s=0):
    return int(datetime(y, mo, d, h, mi, s, tzinfo=IST).timestamp() * 1000)


# ----------------------------------------------------------------------------- stubs
class HTTPException(Exception):
    def __init__(self, status_code, detail=None):
        self.status_code, self.detail = status_code, detail


class RequestValidationError(Exception):
    status_code = 422

    def __init__(self, errors):
        self.errors = errors


class DuplicateKeyError(Exception):
    pass


class OperationFailure(Exception):
    pass


class PyMongoError(Exception):
    pass


def make_stubs():
    m = {}
    fa = types.ModuleType("fastapi")
    fa.FastAPI = type("FastAPI", (), {
        "__init__": lambda self, **kw: None,
        **{v: (lambda self, *a, **k: (lambda f: f)) for v in ("get", "post", "patch")}})
    fa.HTTPException = HTTPException
    fa.Query = lambda default=None, **kw: default
    exc = types.ModuleType("fastapi.exceptions")
    exc.RequestValidationError = RequestValidationError
    resp = types.ModuleType("fastapi.responses")
    resp.JSONResponse = lambda content, status_code=200: NS(content=content, status_code=status_code)
    pd = types.ModuleType("pydantic")
    pd.BaseModel = type("BaseModel", (), {})
    pd.Field = lambda *a, **k: None
    pd.StrictInt, pd.StrictStr = int, str
    pd.field_validator = lambda *a, **k: (lambda f: f)
    pd.model_validator = lambda *a, **k: (lambda f: f)
    pm = types.ModuleType("pymongo")
    pm.MongoClient = lambda *a, **k: mock.MagicMock()
    pme = types.ModuleType("pymongo.errors")
    pme.DuplicateKeyError, pme.OperationFailure, pme.PyMongoError = DuplicateKeyError, OperationFailure, PyMongoError
    bs = types.ModuleType("bson")
    ju = types.ModuleType("bson.json_util")
    ju.RELAXED_JSON_OPTIONS = None
    ju.dumps = lambda o, json_options=None: json.dumps(o, default=str)
    bs.json_util = ju
    de = types.ModuleType("dotenv")
    de.load_dotenv = lambda *a, **k: None
    m.update({"fastapi": fa, "fastapi.exceptions": exc, "fastapi.responses": resp, "pydantic": pd,
              "pymongo": pm, "pymongo.errors": pme, "bson": bs, "bson.json_util": ju, "dotenv": de})
    return m


class Cursor:
    def __init__(self, docs):
        self.docs = docs

    def sort(self, key, direction=None):
        keys = key if isinstance(key, list) else [(key, direction)]
        for k, d in reversed(keys):
            self.docs.sort(key=lambda x: x.get(k), reverse=(d == -1))
        return self

    def skip(self, n):
        self.docs = self.docs[n:]
        return self

    def limit(self, n):
        self.docs = self.docs[:n]
        return self

    def __iter__(self):
        return iter([copy.deepcopy(d) for d in self.docs])


class Coll:
    def __init__(self, unique):
        self.docs, self.unique, self.n, self.lock = [], unique, 0, threading.Lock()

    def _match(self, d, f):
        for k, v in f.items():
            if k == "$expr":
                want = v["$eq"][1]
                if len(d.get("history") or []) != want:
                    return False
            elif isinstance(v, dict) and any(x.startswith("$") for x in v):
                val = d.get(k)
                for op, arg in v.items():
                    if val is None:
                        return False
                    if op == "$lte" and not val <= arg: return False
                    if op == "$gte" and not val >= arg: return False
                    if op == "$gt" and not val > arg: return False
                    if op == "$lt" and not val < arg: return False
            elif d.get(k) != v:
                return False
        return True

    def find(self, f=None):
        return Cursor([d for d in self.docs if self._match(d, f or {})])

    def find_one(self, f, sort=None):
        c = self.find(f)
        if sort:
            c.sort(sort)
        docs = list(c)
        return docs[0] if docs else None

    def count_documents(self, f, limit=None):
        n = len([d for d in self.docs if self._match(d, f)])
        return min(n, limit) if limit else n

    def insert_one(self, doc):
        with self.lock:
            key = tuple(doc.get(k) for k in self.unique)
            if any(tuple(d.get(k) for k in self.unique) == key for d in self.docs):
                raise DuplicateKeyError("dup")
            self.n += 1
            doc["_id"] = self.n
            self.docs.append(copy.deepcopy(doc))

    def update_one(self, f, upd):
        with self.lock:
            for d in self.docs:
                if self._match(d, f):
                    d.update(upd.get("$set", {}))
                    for k, v in upd.get("$push", {}).items():
                        d.setdefault(k, []).append(v)
                    return NS(matched_count=1)
        return NS(matched_count=0)


class FakeDB:
    def __init__(self):
        self.employees = Coll(("emp_code",))
        self.attendance_logs = Coll(("emp_code", "date"))
        self.commands = []

    def command(self, cmd):
        self.commands.append(cmd)
        return {"queryPlanner": {"winningPlan": {"stage": "IXSCAN"}}}


def load_main():
    with mock.patch.dict(sys.modules, make_stubs()):
        spec = importlib.util.spec_from_file_location("app_main_sim", MAIN)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
    return mod


class Base(unittest.TestCase):
    def setUp(self):
        self.m = load_main()
        self.m.db = FakeDB()
        self.db = self.m.db

    def emp(self, code="EMP0001", dept="Eng", ss="09:30", se="18:30", joined="2026-01-05"):
        self.db.employees.insert_one({"emp_code": code, "name": code, "email": "a@b.co", "department": dept,
                                      "shift_start": ss, "shift_end": se, "joined_on": joined,
                                      "created_at": datetime(2026, 1, 1, tzinfo=timezone.utc)})

    def pin(self, code, at, status="PRESENT"):
        return self.m.punch_in(NS(emp_code=code, punched_at=at, status=status))

    def pout(self, code, at):
        return self.m.punch_out(NS(emp_code=code, punched_at=at))

    def status(self, fn, *a, **k):
        try:
            fn(*a, **k)
        except HTTPException as e:
            return e.status_code
        except RequestValidationError:
            return 422
        return 200


class PunchTests(Base):
    def test_punch_in_fields_and_errors(self):
        self.emp()
        r = self.pin("EMP0001", ms(2026, 7, 6, 9, 40, 1) + 900)
        self.assertEqual((r["date"], r["late_minutes"], r["work_hours"], r["history"], r["half_day"]),
                         ("2026-07-06", 10, None, [], False))
        self.assertEqual(r["punch_in"] % 1000, 0)  # truncated to whole seconds
        self.assertNotIn("id", r)
        self.assertNotIn("_id", r)
        self.assertEqual(self.status(self.pin, "EMP0001", ms(2026, 7, 6, 11)), 409)
        self.assertEqual(self.status(self.pin, "NOPE", ms(2026, 7, 6, 11)), 404)

    def test_punch_out_rules(self):
        self.emp()
        self.pin("EMP0001", ms(2026, 7, 6, 10, 5))
        self.assertEqual(self.status(self.pout, "EMP0001", ms(2026, 7, 6, 10, 5)), 422)  # not after
        self.assertEqual(self.status(self.pout, "EMP0001", ms(2026, 7, 7, 10, 6)), 422)  # > 24h
        self.assertEqual(self.status(self.pout, "EMP0001", ms(2026, 7, 6, 9)), 404)  # before any punch-in
        o = self.pout("EMP0001", ms(2026, 7, 6, 19, 10))
        self.assertEqual((o["overtime_minutes"], o["work_hours"], o["late_minutes"], o["half_day"]),
                         (40, 9.08, 35, False))
        self.assertEqual(self.status(self.pout, "EMP0001", ms(2026, 7, 6, 19, 20)), 409)
        self.assertEqual(self.status(self.pout, "NOPE", ms(2026, 7, 6, 19)), 404)

    def test_half_day_on_punch_out(self):
        self.emp()
        self.pin("EMP0001", ms(2026, 7, 7, 9, 30), "WFH")
        o = self.pout("EMP0001", ms(2026, 7, 7, 13, 0))
        self.assertEqual((o["work_hours"], o["half_day"], o["status"]), (3.5, True, "WFH"))

    def test_overnight_across_midnight(self):
        self.emp("EMP0005", ss="22:00", se="06:00")
        r = self.pin("EMP0005", ms(2026, 7, 6, 21, 55))
        self.assertEqual(r["date"], "2026-07-06")
        o = self.pout("EMP0005", ms(2026, 7, 7, 6, 40))
        self.assertEqual((o["work_hours"], o["overtime_minutes"], o["date"]), (8.75, 40, "2026-07-06"))
        self.assertEqual(self.pin("EMP0005", ms(2026, 7, 8, 2, 0))["date"], "2026-07-07")

    def test_parallel_punch_in_one_winner(self):
        self.emp()
        out = []
        ts = [threading.Thread(target=lambda: out.append(self.status(self.pin, "EMP0001", ms(2026, 7, 6, 9, 30))))
              for _ in range(16)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(sorted(out), [200] * 1 + [409] * 15)  # 201 is the handler's normal return (no exception)

    def test_parallel_punch_out_one_winner(self):
        self.emp()
        self.pin("EMP0001", ms(2026, 7, 6, 9, 30))
        out = []
        ts = [threading.Thread(target=lambda: out.append(self.status(self.pout, "EMP0001", ms(2026, 7, 6, 18, 30))))
              for _ in range(16)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(sorted(out), [200] + [409] * 15)


class RegularizeTests(Base):
    def reg(self, code="EMP0001", day="2026-07-06", **kw):
        body = NS(**{"status": None, "punch_in": None, "punch_out": None, "reason": "biometric glitch",
                     "regularized_by": "hr", **kw})
        return self.m.regularize(code, day, body)

    def test_flow(self):
        self.emp()
        self.pin("EMP0001", ms(2026, 7, 6, 10, 5))
        self.pout("EMP0001", ms(2026, 7, 6, 18, 35))
        self.assertEqual(self.status(self.reg), 422)  # nothing changes
        r = self.reg(punch_in=ms(2026, 7, 6, 9, 28))
        ch = r["history"][0]["changes"]
        self.assertEqual(ch["late_minutes"], {"from": 35, "to": 0})
        self.assertEqual(set(ch), {"punch_in", "late_minutes", "work_hours"})
        self.assertIsInstance(ch["punch_in"]["from"], int)
        self.assertEqual((r["late_minutes"], r["work_hours"]), (0, 9.12))
        self.assertEqual(self.status(self.reg, status="LEAVE", punch_in=ms(2026, 7, 6, 9)), 422)
        self.assertEqual(self.status(self.reg, punch_in=ms(2026, 7, 7, 9)), 422)  # other attendance date
        self.assertEqual(self.status(self.reg, punch_out=ms(2026, 7, 6, 9)), 422)  # before punch_in
        self.assertEqual(self.status(self.reg, "EMP0001", "2026-07-09", punch_in=ms(2026, 7, 9, 9)), 404)
        self.assertEqual(self.status(self.reg, "NOPE"), 404)
        r = self.reg(status="LEAVE")
        self.assertEqual((r["punch_in"], r["punch_out"], r["work_hours"], r["overtime_minutes"]), (None, None, None, 0))
        self.assertEqual(len(r["history"]), 2)
        self.assertEqual(self.status(self.reg, status="PRESENT"), 422)  # needs a punch_in

    def test_conflict_when_record_changed_underneath(self):
        self.emp()
        self.pin("EMP0001", ms(2026, 7, 6, 10, 5))
        real = self.db.attendance_logs.find_one

        def racing(f, sort=None):
            rec = real(f, sort)
            # another editor appends a history entry right after we read the record
            for d in self.db.attendance_logs.docs:
                d["history"] = d.get("history", []) + [{"at": None, "by": "x", "reason": "y", "changes": {}}]
            return rec

        self.db.attendance_logs.find_one = racing
        self.assertEqual(self.status(self.reg, punch_in=ms(2026, 7, 6, 9, 28)), 409)


class ListTests(Base):
    def test_employee_paging_and_total(self):
        for i in range(1, 8):
            self.emp(f"EMP000{i}", dept="Ops" if i % 2 else "Eng")
        r = self.m.list_employees("Ops", 1, 3)
        self.assertEqual((r["total"], [e["emp_code"] for e in r["items"]]), (4, ["EMP0001", "EMP0003", "EMP0005"]))
        r = self.m.list_employees("Ops", 2, 3)
        self.assertEqual([e["emp_code"] for e in r["items"]], ["EMP0007"])
        self.assertIsInstance(r["items"][0]["created_at"], int)
        self.assertNotIn("_id", r["items"][0])

    def test_attendance_list_order_and_validation(self):
        for c in ("EMP0002", "EMP0001"):
            self.emp(c)
            self.pin(c, ms(2026, 7, 6, 9, 30))
            self.pin(c, ms(2026, 7, 7, 9, 30))
        r = self.m.list_attendance(None, None, None, None, 1, 3)
        self.assertEqual(r["total"], 4)
        self.assertEqual([(i["date"], i["emp_code"]) for i in r["items"]],
                         [("2026-07-07", "EMP0001"), ("2026-07-07", "EMP0002"), ("2026-07-06", "EMP0001")])
        self.assertEqual(self.m.list_attendance("EMP0001", "2026-07-07", None, None, 1, 20)["total"], 1)
        self.assertEqual(self.status(self.m.list_attendance, None, "2026-07-09", "2026-07-01", None, 1, 20), 422)
        self.assertEqual(self.status(self.m.list_attendance, None, "2026-02-30", None, None, 1, 20), 422)

    def test_create_employee_duplicate_and_created_at(self):
        body = NS(model_dump=lambda: {"emp_code": "EMP0042", "name": "n", "email": "a@b.co", "department": "d",
                                      "shift_start": "09:30", "shift_end": "18:30", "joined_on": "2026-01-01"})
        r = self.m.create_employee(body)
        self.assertIsInstance(r["created_at"], int)
        self.assertNotIn("_id", r)
        self.assertEqual(self.status(self.m.create_employee, body), 409)


class PipelineAndExplainTests(Base):
    def test_pipelines_build_and_serialise(self):
        m = self.m
        f, l = m.month_bounds("2026-07")
        for p in (m.employee_monthly_pipeline("EMP0001", f, l), m.department_summary_pipeline(f, l, "Eng"),
                  m.leaderboard_pipeline(f, l, 5, None), m.trend_pipeline("Eng", f, l)):
            json.dumps(p, default=str)
        lb = json.dumps(m.leaderboard_pipeline(f, l, 3, "Eng"), default=str)
        self.assertIn("$rank", lb)
        self.assertLess(lb.index('"rank"'), lb.index('"$lte"', lb.index("$setWindowFields")))  # limit after ranking
        trend = m.trend_pipeline("Eng", f, l)
        self.assertEqual(trend[3]["$project"]["rows"]["$map"]["input"], {"$range": [0, 31]})
        self.assertEqual(m.department_summary_pipeline(f, l, None)[0], {"$match": {"joined_on": {"$lte": "2026-07-31"}}})

    def test_explain_builds_same_query_as_endpoint(self):
        kw = dict(emp_code="EMP0001", month=None, department=None, limit=10, date_from="2026-07-01",
                  date_to="2026-07-31", status="PRESENT", from_=None, to=None, page=3, page_size=5)
        r = self.m.explain_endpoint("attendance_list", **kw)
        cmd = self.db.commands[-1]
        self.assertEqual(cmd["verbosity"], "executionStats")
        self.assertEqual(cmd["explain"], {
            "find": "attendance_logs", "skip": 10, "limit": 5, "sort": {"date": -1, "emp_code": 1},
            "filter": {"emp_code": "EMP0001", "date": {"$gte": "2026-07-01", "$lte": "2026-07-31"},
                       "status": "PRESENT"}})
        self.assertEqual((r.content["endpoint"], r.content["collection"]), ("attendance_list", "attendance_logs"))

    def test_explain_collections_and_required_params(self):
        base = dict(emp_code=None, month=None, department=None, limit=10, date_from=None, date_to=None,
                    status=None, from_=None, to=None, page=1, page_size=20)
        self.assertEqual(self.status(self.m.explain_endpoint, "employee_monthly", **base), 422)
        self.assertEqual(self.status(self.m.explain_endpoint, "department_summary", **base), 422)
        self.assertEqual(self.status(self.m.explain_endpoint, "late_leaderboard", **base), 422)
        self.assertEqual(self.status(self.m.explain_endpoint, "department_trend", **base), 422)
        got = {}
        for ep, extra in (("employee_monthly", dict(emp_code="EMP0001", month="2026-07")),
                          ("department_summary", dict(month="2026-07")),
                          ("late_leaderboard", dict(month="2026-07")),
                          ("department_trend", dict(department="Eng", from_="2026-07-01", to="2026-07-31"))):
            got[ep] = self.m.explain_endpoint(ep, **{**base, **extra}).content["collection"]
        self.assertEqual(got, {"employee_monthly": "attendance_logs", "department_summary": "employees",
                               "late_leaderboard": "attendance_logs", "department_trend": "employees"})


if __name__ == "__main__":
    unittest.main()
