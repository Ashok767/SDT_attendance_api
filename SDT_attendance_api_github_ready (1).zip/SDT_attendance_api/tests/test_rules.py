"""Stdlib-only unit tests for the pure business rules (R1-R5, R7, R8) in app/main.py.

The rules live between the '>>> PURE RULES BEGIN' and '<<< PURE RULES END' markers; this file executes only that
block, so it needs no FastAPI / PyMongo / MongoDB.   Run:  python -m unittest tests.test_rules -v
"""
import pathlib
import unittest

SRC = (pathlib.Path(__file__).resolve().parent.parent / "app" / "main.py").read_text()
BLOCK = SRC.split("# >>> PURE RULES BEGIN", 1)[1].split("\n", 1)[1].split("# <<< PURE RULES END", 1)[0]
NS: dict = {}
exec("import re\nfrom datetime import date, datetime, timedelta, timezone\n"
     "from decimal import Decimal, ROUND_HALF_UP\nfrom typing import Optional\n" + BLOCK, NS)
globals().update({k: v for k, v in NS.items() if not k.startswith("__")})


def ist(y, mo, d, h=0, mi=0, s=0, us=0):
    return datetime(y, mo, d, h, mi, s, us, tzinfo=IST)


class Late(unittest.TestCase):  # R2, shift 09:30
    def late(self, h, m, s):
        return compute_late_minutes(ist(2026, 7, 6, h, m, s), "2026-07-06", "09:30")

    def test_spec_examples(self):
        self.assertEqual(self.late(9, 40, 0), 0)
        self.assertEqual(self.late(9, 40, 1), 10)
        self.assertEqual(self.late(10, 15, 59), 45)

    def test_early_and_on_time(self):
        self.assertEqual(self.late(9, 0, 0), 0)
        self.assertEqual(self.late(9, 30, 0), 0)

    def test_sample_late_35(self):
        self.assertEqual(self.late(10, 5, 0), 35)

    def test_subsecond_is_truncated(self):
        ts = ist(2026, 7, 6, 9, 40, 0, 900000)  # 09:40:00.900 counts as 09:40:00
        self.assertEqual(compute_late_minutes(ts, "2026-07-06", "09:30"), 0)


class WorkHours(unittest.TestCase):  # R4, R5
    def test_samples(self):
        self.assertEqual(compute_work_hours(ist(2026, 7, 6, 9, 28), ist(2026, 7, 6, 18, 35)), 9.12)  # 9.1167
        self.assertEqual(compute_work_hours(ist(2026, 7, 7, 9, 30), ist(2026, 7, 7, 13, 0)), 3.5)

    def test_half_up_not_bankers(self):
        # 2.025 h = 7290 s exactly -> 2.03 half-up (banker's/float would give 2.02)
        pin = ist(2026, 7, 6, 9, 0)
        self.assertEqual(compute_work_hours(pin, pin + timedelta(seconds=7290)), 2.03)
        # 4.005 h = 14418 s -> 4.01
        self.assertEqual(compute_work_hours(pin, pin + timedelta(seconds=14418)), 4.01)

    def test_half_day_uses_rounded_value(self):
        pin = ist(2026, 7, 6, 9, 0)
        # 4.496 h rounds to 4.50 -> NOT a half day
        wh = compute_work_hours(pin, pin + timedelta(seconds=int(4.496 * 3600)))
        self.assertEqual(wh, 4.5)
        self.assertFalse(compute_half_day(wh))
        self.assertTrue(compute_half_day(4.49))
        self.assertTrue(compute_half_day(3.5))
        self.assertFalse(compute_half_day(9.0))


class Overtime(unittest.TestCase):  # R3
    def ot(self, h, m, s=0, ss="09:30", se="18:30", day="2026-07-06", d=6):
        return compute_overtime(ist(2026, 7, d, h, m, s), day, ss, se)

    def test_below_minimum(self):
        self.assertEqual(self.ot(18, 35), 0)
        self.assertEqual(self.ot(18, 59, 59), 0)  # 29 min 59 s

    def test_at_minimum_and_above(self):
        self.assertEqual(self.ot(19, 0, 0), 30)
        self.assertEqual(self.ot(19, 10), 40)
        self.assertEqual(self.ot(19, 0, 59), 30)  # floor

    def test_early_leaver(self):
        self.assertEqual(self.ot(17, 0), 0)

    def test_overnight_shift_ends_next_day(self):
        # 22:00-06:00, shift started 2026-07-06, punch-out 06:40 on the 7th -> 40
        self.assertEqual(compute_overtime(ist(2026, 7, 7, 6, 40), "2026-07-06", "22:00", "06:00"), 40)
        self.assertEqual(compute_overtime(ist(2026, 7, 7, 6, 10), "2026-07-06", "22:00", "06:00"), 0)


class AttendanceDate(unittest.TestCase):  # R1
    def test_day_shift(self):
        self.assertEqual(attendance_date(ist(2026, 7, 6, 9, 30), "09:30", "18:30"), "2026-07-06")

    def test_ist_vs_utc_boundary(self):
        # 2026-07-05 20:00 UTC == 2026-07-06 01:30 IST -> IST date is the 6th
        ts = datetime(2026, 7, 5, 20, 0, tzinfo=UTC)
        self.assertEqual(attendance_date(ts, "09:30", "18:30"), "2026-07-06")

    def test_overnight_evening_punch_in(self):
        self.assertEqual(attendance_date(ist(2026, 7, 6, 21, 55), "22:00", "06:00"), "2026-07-06")

    def test_overnight_early_morning_belongs_to_previous_day(self):
        self.assertEqual(attendance_date(ist(2026, 7, 7, 2, 0), "22:00", "06:00"), "2026-07-06")
        self.assertEqual(attendance_date(ist(2026, 7, 7, 5, 59, 59), "22:00", "06:00"), "2026-07-06")
        self.assertEqual(attendance_date(ist(2026, 7, 7, 6, 0, 0), "22:00", "06:00"), "2026-07-07")

    def test_overnight_across_month_boundary(self):
        self.assertEqual(attendance_date(ist(2026, 8, 1, 1, 0), "22:00", "06:00"), "2026-07-31")


class DerivedAndSamples(unittest.TestCase):
    def test_sample_normal_day(self):  # DATA_MODEL sample 1
        d = derive_fields("PRESENT", ist(2026, 7, 6, 9, 28), ist(2026, 7, 6, 18, 35), "2026-07-06", "09:30", "18:30")
        self.assertEqual(d, {"work_hours": 9.12, "late_minutes": 0, "overtime_minutes": 0, "half_day": False})

    def test_sample_late_with_overtime(self):  # sample 2 (work_hours 9.08)
        d = derive_fields("PRESENT", ist(2026, 7, 6, 10, 5), ist(2026, 7, 6, 19, 10), "2026-07-06", "09:30", "18:30")
        self.assertEqual(d, {"work_hours": 9.08, "late_minutes": 35, "overtime_minutes": 40, "half_day": False})

    def test_sample_overnight(self):  # sample 7
        d = derive_fields("PRESENT", ist(2026, 7, 6, 21, 55), ist(2026, 7, 7, 6, 40), "2026-07-06", "22:00", "06:00")
        self.assertEqual(d, {"work_hours": 8.75, "late_minutes": 0, "overtime_minutes": 40, "half_day": False})

    def test_open_record(self):
        d = derive_fields("PRESENT", ist(2026, 7, 7, 9, 35), None, "2026-07-07", "09:30", "18:30")
        self.assertEqual(d, {"work_hours": None, "late_minutes": 0, "overtime_minutes": 0, "half_day": False})

    def test_absent_leave_are_zero(self):
        for st in ("ABSENT", "LEAVE"):
            self.assertEqual(derive_fields(st, None, None, "2026-07-08", "09:30", "18:30"),
                             {"work_hours": None, "late_minutes": 0, "overtime_minutes": 0, "half_day": False})


class Conversions(unittest.TestCase):
    def test_ms_roundtrip(self):
        ms = 1783312500123
        self.assertEqual(dt_to_ms(ms_to_dt(ms)), ms)

    def test_punch_truncation(self):
        self.assertEqual(dt_to_ms(ms_to_punch(1783312500999)), 1783312500000)
        self.assertEqual(ms_to_punch(1783312500999).microsecond, 0)

    def test_naive_treated_as_utc(self):
        self.assertEqual(dt_to_ms(datetime(1970, 1, 1, 0, 0, 1)), 1000)

    def test_sample_instant(self):  # sample 1: 2026-07-06T03:58:00Z == 09:28 IST
        ts = datetime(2026, 7, 6, 3, 58, tzinfo=UTC)
        self.assertEqual(ts.astimezone(IST).strftime("%H:%M"), "09:28")


class Calendar(unittest.TestCase):  # R7, R8
    def test_month_bounds(self):
        self.assertEqual(month_bounds("2026-02"), (date(2026, 2, 1), date(2026, 2, 28)))
        self.assertEqual(month_bounds("2024-02")[1], date(2024, 2, 29))
        self.assertEqual(month_bounds("2026-12")[1], date(2026, 12, 31))

    def test_bad_months(self):
        for bad in ("2026-13", "2026-00", "2026-7", "abcd-01", "0000-01", "2026-07-01"):
            with self.assertRaises(ValueError):
                month_bounds(bad)

    def test_working_days(self):
        f, l = month_bounds("2026-07")
        self.assertEqual(count_weekdays(f, l), 23)  # July 2026: 23 Mon-Fri
        self.assertEqual(count_weekdays(date(2026, 7, 15), l), 13)  # mid-month joiner
        self.assertEqual(count_weekdays(date(2026, 7, 4), date(2026, 7, 5)), 0)  # weekend only

    def test_parse_iso_date(self):
        self.assertEqual(parse_iso_date("2026-07-06"), date(2026, 7, 6))
        for bad in ("2026-02-30", "2026-7-6", "20260706", "2026-07-06T00:00", "", "٢٠٢٦-٠٧-٠٦"):
            with self.assertRaises(ValueError):
                parse_iso_date(bad)

    def test_round_half_up(self):
        self.assertEqual(round_half_up(2.675, 2), 2.68)  # float round() gives 2.67
        self.assertEqual(round_half_up(0.125, 2), 0.13)
        self.assertEqual(round_half_up(0.41665, 4), 0.4167)
        self.assertEqual(round_half_up(66.666666, 2), 66.67)
        self.assertEqual(round_half_up(0.5, 0), 1.0)


class Overnight(unittest.TestCase):
    def test_is_overnight(self):
        self.assertTrue(is_overnight("22:00", "06:00"))
        self.assertTrue(is_overnight("09:30", "09:30"))  # equal counts as overnight per R1 (rejected at create)
        self.assertFalse(is_overnight("09:30", "18:30"))


if __name__ == "__main__":
    unittest.main()
